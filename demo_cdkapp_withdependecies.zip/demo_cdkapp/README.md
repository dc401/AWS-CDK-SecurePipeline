
# CDK CI/CD Pipeline Demo with Cloudformation Scanning

This is a CDK built 1.84 Python App
This project creates a CI/CD pipeline using general best practices and will also auto check the 
cloud formation synthesized templates for insecure configurations and fail at build time if 
not corrected. Build time will also fail for insecure python code scanned by bandit.

Extract the demo_cdkapp.zip into a temporary folder. Create a folder called demo_cdkapp
run the cdk init --language python command and then replace the project files with
the extracted files.

```
$ gunzip -c demo_cdkapp.zip /tmp/demo_cdkapp
$ mkdir demo_cdkapp && demo_cdkapp && cdk init --language python
$ cp /tmp/demo_cdkapp/* ./
```


Run the following to deploy the cdk pipeline and app

```
$ python -m venv .venv
```

After the init process completes and the virtualenv is created, you can use the following
step to activate your virtualenv.

```
$ source .venv/bin/activate
```

If you are a Windows Powershell platform, you would activate the virtualenv like this:

```
. .venv\Scripts\activate.ps1
```

Once the virtualenv is activated, you can install the required dependencies.

```
$ pip install -r requirements.txt
```

At this point you can now synthesize the CloudFormation template for this code.

```
$ cdk synth
```

You can now begin exploring the source code, contained in the hello directory.
There is also a very trivial test included that can be run like this:

```
$ cdk bootstrap --cloudformation-execution-policies arn:aws:iam::aws:policy/AdministratorAccess
```

Deploy your app to the AWS account

```
$ cdk deploy
```

Ensure you have generated your git credentials within IAM and run the following to initialize

```
$ git init; git add -A; git commit -m 'initialize'
```

Add the origin master git to whichever repo and region you had made (or modified)

```
$ git remote add origin https://git-codecommit.us-west-2.amazonaws.com/v1/repos/demo_cicid_pipeline_repo
$ git push --set-upstream origin master
```


If you wish to simulate an intentional sbuild failure based on insecure stack code uncomment the bottom of cdkpipeline_stack.py
After uncommenting, save, and do a git push. There's also basic SCA on our lambda app using bandit.
Alternatively you can save, and run cdk synth followed by
bridgecrew.cmd -f .\cdk.out\CdkPipelineStack.template.json --check CKV_AWS_27
bandit -r .\lambda\

```
$ git push
OR to test locally
$ cdk synth
$ bridgecrew.cmd -f .\cdk.out\CdkPipelineStack.template.json --check CKV_AWS_27
$ bandit -r .\lambda\
```

Clean up and removal. Run cdk destroy and then delete any cloudformation stacks and s3 bootstrap and code artifact buckets remaining.

```
$ cdk destroy
```