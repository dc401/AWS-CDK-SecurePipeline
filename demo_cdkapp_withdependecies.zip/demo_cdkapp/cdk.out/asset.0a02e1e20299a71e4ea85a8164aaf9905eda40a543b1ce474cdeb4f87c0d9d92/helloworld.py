#!/usr/env/python 3
import os
def handler(event, context):
    print('hello world')
    #intentional poor performing proc call
    result = str(os.system('ls -lah; whoami'))
    #intentional no input filtering eval statement
    #replace 2+2 with event or context if you wish
    something = eval('2+2')
    return result




